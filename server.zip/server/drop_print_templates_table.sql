
-- Migration to drop print_templates table
DROP TABLE IF EXISTS print_templates CASCADE;
