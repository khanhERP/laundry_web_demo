
-- Add receiver_name column to income_vouchers table
ALTER TABLE income_vouchers 
ADD COLUMN IF NOT EXISTS receiver_name VARCHAR(255);
-- Add receiver_name column to income_vouchers table
ALTER TABLE income_vouchers 
ADD COLUMN IF NOT EXISTS receiver_name VARCHAR(255);
